
function showLove() {
  document.getElementById("love").style.display = "block";
}
